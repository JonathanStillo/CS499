from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        
        #The local server it is meant to connect to
        self.client = MongoClient('mongodb://%s:%s@localhost:32580/test?authSource=AAC' % ("aacuser", "aacuser"))

        #The database it uses/connects to
        self.database = self.client["AAC"]

#Bonus Methods -----------------------------------------------------

# Created a method for counting the documents in the database
    def count(self, query: dict) -> cursor.Cursor:
        if query is not None and type(query) is dict:

            #counts the database files according to their id
            return self.database.animals.count(query, {"_id": False})
        else:
            raise Exception("Count Error, incorrect or no input")


# Created a method for replacing a file/document in the database
    def replaceFiles(self, query: dict, changes: dict) -> str:
        if (query is not None and type(query) is dict) and (changes is not None and type(changes) is dict):

            #The command for replacing only one of the files/documents in the database
            replaced = self.database.animals.replace_one(query, changes)
            return dumps(replaced.raw_results)
        else:
            raise Exception("Update error: invalid replacement parameters")


# Created a method for replacing multiple files/documents in the database
    def replaceMultipleFiles(self, query: dict, changes: dict) -> str:

        if (query is not None and type(query) is dict) and (changes is not None and type(changes) is dict):
            
            #The command for replacing multiple files/documents in the database
            replaced = self.database.animals.replace_many(query, changes)
            return dumps(replaced.raw_results)
        else:
            raise Exception("Update error: invalid replacement parameters")


#End of Bonus Methods ------------------------------------------------


# A Create Method for creating documents/files for the database
    def create(self, data):
        if data is not None:

            #The command for creating one file/document
            insert = self.database.animals.insert(data)
            if insert != 0:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Loads multiple files into the database
    def loadMultiple(self, data: dict) -> bool:

        if data is not None and type(data) is dict:
            try:
                self.database.animals.insert_many(data)
                return True
            except Exception as e:
                print("An exception has occured ::", e)
            return False
        else:
            #Exception for empty database
            raise Exception("Nothing to save, because data parameter is empty")

# Created a method for reading/searching for files/documents in the database
    def read(self, criteria=None):
        if criteria is not None:

            #The command for reading/searching a file/document
            data = self.database.animals.find(criteria,{"_id": False})
            
        else:
            data = self.database.animals.find({},{"_id": False})
        
        return data
    
# Created a method for updating the current file/document in the database
    def update(self, initial, change):
        if initial is not None:

            #This does use the update multiple method, but limited to one
            if self.database.animals.count_documents(initial, limit = 1) != 0:

                #The command for updating one file/document
                update_result = self.database.animals.update_many(initial, {"$set": change})
                result = update_result.raw_result
            else:

            #Exception for the document not being found
                result = "No document was found"
            return result
        else:

            #Exception for the update being the same
            raise Exception("Nothing to update, because data parameter is empty")

 # Created a method that updates multiple files at once
    def updateMultiple(self, query: dict, changes: dict) -> str:
        """Update multiple documents in the AAC database"""
        if (query is not None and type(query) is dict) and (changes is not None and type(changes) is dict):

            #The command for updating one file/document
            updated = self.database.animals.update_many(query, changes)
            return dumps(updated.raw_results)
        else:

            #Exception for no or incorrect parameters
            raise Exception("Update error, invalid or no input")

# Created a method for deleting the current files/documents in the database
    def delete(self, remove):
        if remove is not None:
            if self.database.animals.count_documents(remove, limit = 1) != 0:

                #The command for deleting one file/document
                delete_result = self.database.animals.delete_many(remove)
                result = delete_result.raw_result
            else:
                result = "No document was found"
            return result
        else:
            raise Exception("Nothing to delete, because data parameter is empty")

    # Created a method for deleting multiple files/documents from database
    def deleteMultiple(self, remove: dict) -> str:
        if remove is not None and type(remove) is dict:

            #The command for deleting multiple files
            deleted = self.database.animals.delete_many(remove)
            return dumps(deleted.raw_result)
        else:
            raise Exception("Delete error: invalid delete parameter")    # exception thrown for invalid deletion

