#This is the grid that represents the sudoku board
grid = [
    [9, 0, 0, 0, 0, 6, 0, 0, 0],
    [2, 0, 7, 0, 3, 0, 6, 0, 0],
    [0, 6, 0, 0, 0, 9, 0, 0, 2],
    [8, 5, 9, 0, 1, 0, 0, 2, 6],
    [7, 4, 2, 0, 6, 5, 3, 0, 0],
    [1, 3, 0, 0, 8, 2, 5, 0, 0],
    [5, 7, 0, 0, 0, 0, 0, 6, 3],
    [0, 9, 0, 0, 5, 8, 2, 0, 0],
    [0, 0, 0, 6, 9, 7, 0, 5, 1]
]

#This method is for working out the grid of the sudoku board
def workOut(grid, a=0, b=0):
    if a == 9:
        return True
    elif b == 9:
        return workOut(grid, a+1, 0)
    elif grid[a][b] != 0:
        return workOut(grid, a, b+1)
    else:
        for k in range(1, 10):
            if is_Sorted(grid, a, b, k):
                grid[a][b] = k
                if workOut(grid, a, b+1):
                    return True
                grid[a][b] = 0
        return False
# Double check the values and make sure they're valid to be sorted, the calculations are made/chosen from original project
def is_Sorted(grid, a, b, c):
    row = c not in grid[a]
    column = c not in [grid[i][b] for i in range(9)]
    box = c not in [grid[i][j] for i in range(a//3*3, a//3*3+3) for j in range(b//3*3, b//3*3+3)]
    return row and column and box
    
workOut(grid)
#calling the function to print the solved grid out
print(*grid, sep='\n')