public class SudokuSolver {
  
  private static final int GRID_SIZE = 9;
  
//This method is for printing the solved grid out
private static void printGrid(int[][] grid) {
    for (int r = 0; r < GRID_SIZE; r++) {
      if (r % 3 == 0 && r != 0) {
        System.out.println("___________");
      }
      for (int c = 0; c < GRID_SIZE; c++) {
        if (c % 3 == 0 && c != 0) {
          System.out.print("|");
        }
        System.out.print(grid[r][c]);
      }
      System.out.println();
    }
  }

//This boolean is for ensuring the original grid provided is solved
  private static boolean gridSolver(int[][] grid) {
    for (int r = 0; r < GRID_SIZE; r++) {
      for (int c = 0; c < GRID_SIZE; c++) {
        if (grid[r][c] == 0) {
          for (int numberAttempt = 1; numberAttempt <= GRID_SIZE; numberAttempt++) {
            if (is_Sorted(grid, numberAttempt, r, c)) {
              grid[r][c] = numberAttempt;
              
              if (gridSolver(grid)) {
                return true;
              }
              else {
                grid[r][c] = 0;
              }
            }
          }
          return false;
        }
      }
    }
    return true;
  }
//This boolean is to make sure no box is empty
  private static boolean isBoxEmpty(int[][] grid, int n, int r, int c) {
    int boxR = r - r % 3;
    int boxC = c - c % 3;
//boxR = box in the row while boxC is for the boxes in the columns
    for (int i = boxR; i < boxR + 3; i++) {
      for (int j = boxC; j < boxC + 3; j++) {
        if (grid[i][j] == n) {
          return true;
        }
      }
    }
    return false;
  }

//This boolean is to check to make sure no Column is empty
  private static boolean isColumnEmpty(int[][] grid, int n, int c) {
    for (int i = 0; i < GRID_SIZE; i++) {
      if (grid[i][c] == n) {
        return true;
      }
    }
    return false;
  }
//This boolean is to check to make sure no Row is empty
  private static boolean isRowEmpty(int[][] grid, int n, int r) {
    for (int i = 0; i < GRID_SIZE; i++) {
      if (grid[r][i] == n) {
        return true;
      }
    }
    return false;
  }

//This boolean is to check to make sure the row, columns, and boxes are not empty thus solved for
  private static boolean is_Sorted(int[][] grid, int n, int r, int c) {
    return !isRowEmpty(grid, n, r) &&
        !isColumnEmpty(grid, n, c) &&
        !isBoxEmpty(grid, n, r, c);
  }
//The main method where we input the grid and call the methods up above to solve
  public static void main(String[] args) {
//This is the grid that represents the sudoku board
        int[][] grid = {
            {9, 0, 0, 0, 0, 6, 0, 0, 0},
            {2, 0, 7, 0, 3, 0, 6, 0, 0},
            {0, 6, 0, 0, 0, 9, 0, 0, 2},
            {8, 5, 9, 0, 1, 0, 0, 2, 6},
            {7, 4, 2, 0, 6, 5, 3, 0, 0},
            {1, 3, 0, 0, 8, 2, 5, 0, 0},
            {5, 7, 0, 0, 0, 0, 0, 6, 3},
            {0, 9, 0, 0, 5, 8, 2, 0, 0},
            {0, 0, 0, 6, 9, 7, 0, 5, 1}
          };
    
        
        
//calling the function to print the grid out
        printGrid(grid);
        
        if (gridSolver(grid)) {
          System.out.println("We have solved the grid!!");
        }
        else {
          System.out.println("This game is impossible to solve");
        }
        
        printGrid(grid);
        
      }

}